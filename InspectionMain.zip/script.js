var button = document.getElementById('button1');
button.onclick = function() {
    console.log('Try inspect element');
}